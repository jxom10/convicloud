<?php


phpinfo();
?>
