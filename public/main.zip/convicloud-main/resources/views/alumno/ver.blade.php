@extends('layouts.app')


@section('contenido')
	<div class='row justify-content-center'>
		<div class="col text-center bg-primary text-white">
			<h1>{{$titulo}} alumno</h1>
		</div>
	</div>


		<div class='row p-2 justify-content-center'>
      
      <div class='col-sm-8'>
        <form method='POST' action='{{route('alumno_grabar')}}'>
          @csrf
          <input type=hidden name='id' value='{{$alumno->id}}'>
          <label for="nombre">Nombre</label>
          <input type="text" class="form-control" id="nombre" name="nombre"  placeholder="nombre" value='{{$alumno->nombre}}'>
      </div>
      
    </div>
      
		<div class='row p-2 justify-content-center'>
      
			<div class='col-sm-12 col-md-8'>
        <label for="apellido1">Primer apellido</label>
        <input type="text" class="form-control" id="apellido1" name="apellido1"  placeholder="apellido1" value='{{$alumno->apellido1}}'>
      </div>
      
    </div>
		<div class='row p-2 justify-content-center'>
      
			<div class='col-sm-12 col-md-8'>
        <label for="apellido2">Segundo apellido</label>
        <input type="text" class="form-control" id="apellido2" name="apellido2"  placeholder="apellido2" value='{{$alumno->apellido2}}'>
      </div>
      
    </div>

		<div class='row p-2 justify-content-center'>
      
			<div class='col-sm-12 col-md-3'>
        <label for="nia">NIA</label>
        <input type="text" class="form-control" id="apellido2" name="nia"  placeholder="nia" value='{{$alumno->nia}}'>
      </div>
			<div class='col-sm-12 col-md-3'>
        <label for="nia">fecha Nacimiento</label>
        <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento"   value='{{date('Y-m-d',strtotime($alumno->fecha_nacimiento))}}'>
      </div>
			<div class='col-sm-12 col-md-2'>  
        <label for="genero">Genero</label>
      
			<select name='genero' class='form-control'>
				<option value="" @if( $alumno->genero == 'E') selected  @endif> ... </option>
				<option value="O" @if( $alumno->genero == 'O') selected  @endif> MASCULINO</option>
				<option value="A" @if( $alumno->genero == 'A') selected  @endif> FEMENINO</option>
			</select>
   
      </div>
      
    </div>
      
		<div class='row p-2 justify-content-center'>

			<div class='col-sm-12 col-md-3'>
        <label for="curso">Curso</label>
        <input type="text" class="form-control" id="curso" name="curso"  placeholder="curso" value='{{$alumno->curso}}'>
      </div>
			<div class='col-sm-12 col-md-3'>
        <label for="grupo">Grupo</label>
        <input type="text" class="form-control" id="grupo" name="grupo"   value='{{$alumno->grupo}}'>
      </div>
      <div class="form-check form-switch col-md-2">
		<br>
		<input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked"@if($alumno->active==1) checked  @endif >
		<label class="form-check-label text-start" for="flexSwitchCheckChecked">Activo</label>
	</div>
      
    </div>
		<div class='row p-2 justify-content-center'>
			<div class='col-sm-12 col-md-6'>
          <button type="submit" class="btn btn-primary btn-lg">Grabar</button>
          </form>
        </div>    
	</div>
	<div class='row m-2 justify-content-left'>
			<div class='row'>
		Expedientes:
		</div>
		@foreach($alumno->expedientes as $exp)
		  <div class='col-1'>
			<a href="{{route('expediente_ver',$exp->id)}}"><button class='btn btn-primary'>{{$exp->id}}</button></a>
				</div>
		@endforeach
</div>
<div class='row justify-content-left m-2'>
	<div class='row'>
		casos:<br>
		</div>
    @foreach($alumno->casos as $caso)
    <div class='col-1'>
		<a href="{{route('caso_ver',$caso->id_caso)}}"><button class='btn btn-primary'>{{$caso->id_caso}}</button></a>
	</div>
	@endforeach
</div>
<div class='row m-2 justify-content-left'>
		<div class='row'>
	Partes:
	</div>
    @foreach($alumno->partes as $parte)
      <div class='col-1'>
		<a href="{{route('parte_ver',$parte->id)}}"><button class='btn btn-primary'>{{$parte->id}}</button></a>
			</div>
	@endforeach
</div>


@endsection
